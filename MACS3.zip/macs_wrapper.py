# Input BAM File, optional control file

#!/usr/bin/env python3

import sys
import argparse
from io import StringIO
import os
import subprocess
from subprocess import PIPE, STDOUT
import time

### Code for Inputs
parser = argparse.ArgumentParser()

### Module Required Arguments
parser.add_argument("-t", "--treatment",
                    type = str,
                    help ="Name of the ChIP tag file to be read")

# ~~~~Optional Arguments~~~~~ #
parser.add_argument("-c", "--control",
                    type = str,
                    help ="Name of the control file to be read")
parser.add_argument("-n", "--name",
                    type=str,
                    help="The name string of the experiment used as the basename for output files")
parser.add_argument("--outdir",
                    type=str,
                    help="Specified Folder for Output Files to be saved to")
parser.add_argument("-f", "--format",
                    type=str,
                    help="Format of the tag file")
parser.add_argument("-g", "--gsize",
                    type=str,
                    help="Mappable Genome Size")
parser.add_argument("-s", "--tsize",
                    type=int,
                    help="Size of Sequencing Tags")
parser.add_argument("-q", "--qvalue",
                    type=float,
                    help="The q-value (minimum FDR) cutoff to call significant regions")
parser.add_argument("-p", "--pvalue",
                    type=float,
                    help="The p-value cutoff to call significant regions. If specified, MACS3 will use p-value instead of q-value")              

# min-length to minlength
parser.add_argument("--minlength",
                    type=int,
                    help="Specifies the minimum length if a called peak")

# max-gap to maxgap
parser.add_argument("--maxgap",
                    type=str,
                    help="Specifies the maximum gap between nearby peaks, where two nearby peaks smaller than max-gap will be merged as one")

parser.add_argument("--nolambda",
                    type=str,
                    help="Specifies if MACS uses background lambda as local lambda")
parser.add_argument("--slocal",
                    type=int,
                    help="This parameter checks the small local region around peak regions to calculate maximum lambda as local lambda")
parser.add_argument("--llocal",
                    type=int,
                    help="This parameter checks the large local region around peak regions to calculate maximum lambda as local lambda")
parser.add_argument("--nomodel",
                    type=str,
                    help="While on, MACS bypasses building the shifting model")

# ext-size to extsize
parser.add_argument("--extsize",
                    type=str,
                    help="While on, MACS extends reads in the 5'->3' direction to fix-sized fragments. This option is only valid when '--nomodel' is set or when MACS fails to build model and '--fix-bimodal' is on")
parser.add_argument("--shift",
                    type=int,
                    help="Sets an arbitrary shift in base pairs. If '--nomodel' is set, MACS will use this value to move cutting ends (5') then apply '--extsize' in the 5'->3' direction or 3'->5' direction if the value is negative")

# KEEP-DUP, TO KEEPDUP
parser.add_argument("--keepdup",
                    type=str,
                    help="Specifies the number of duplicate tags kept at the exact same location")
parser.add_argument("--broad",
                    type=str,
                    help="While on, MACS will try to composite broad regions by putting nearby highly enriched regions into a broad region with a loose cutoff controlled by '--broad-cutoff'")

# broad-cutoff to broadcutoff
parser.add_argument("--broadcutoff",
                    type=float,
                    help="Cutoff for broad region. If '-p' is set, this is the p-value cutoff")

# scale-to to scaleto
parser.add_argument("--scaleto",
                    type=str,
                    help="Specifies which dataset is scaled, where 'large' linearly scales the smaller dataset to the same depth as the large dataset and 'small' scales the larger dataset towards the smaller dataset")

parser.add_argument("-B", "--bdg",
                    type=str,
                    help="While on, MACS stores fragment pileup and control lambda in bedGraph files")

# call-summits to callsummits
parser.add_argument("--callsummits",
                    type=str,
                    help="While on, MACS will reanalyze the shape of the signal profile to deconvolve subpeaks within each peak. The output subpeaks of a big peak region will have the same peak boundaries, different scores and peak summit position")

# buffer-size to buffersize
parser.add_argument("--buffersize",
                    type=int,
                    help="MACS uses a buffer size for incrementally increasing array size to store read alignment information for each chromosome.")
args = parser.parse_args()

buff = StringIO()

buff.write("macs3 callpeak -t")

file_list = args.treatment

# Treatment
if file_list.endswith(".txt"):
    with open(file_list) as f:
        content = f.readlines()
    content = [x.strip() for x in content]
    for x in content:
        buff.write(" ")
        buff.write(x)
else:
    buff.write(" ")
    buff.write(file_list)

# Control
if args.control != "None":
    buff.write(" -c ")
    buff.write(args.control)

# Output Name
if args.name != "None":
    buff.write(" -n ")
    buff.write(args.name)

# Output Directory
if args.outdir != "None":
    buff.write(" --outdir=")
    buff.write(args.outdir)

# Tag File Format
if args.format:
    buff.write(" -f ")
    buff.write(args.format)

# Genome Size
if args.gsize != "None":
    buff.write(" -g ")
    buff.write(args.gsize)

# Tag Size
if args.tsize != 0:
    buff.write(" -s ")
    buff.write(str(args.tsize))

# Q-value
if args.qvalue != 0:
    buff.write(" -q ")
    buff.write(str(args.qvalue))

# P-value
if args.pvalue != 0:
    buff.write(" -p ")
    buff.write(str(args.pvalue))

# Min-length
if args.minlength != -1:
    buff.write(" --min-length=")
    buff.write(str(args.minlength))

# Max-Gap
if args.maxgap != 0:
    buff.write(" --max-gap=")
    buff.write(str(args.maxgap))

# No Lambda
if args.nolambda == "True":
    buff.write(" --nolambda")

# Small Local
if args.slocal != 1000:
    buff.write(" --slocal=")
    buff.write(str(args.slocal))

# Large Local
if args.llocal != 10000:
    buff.write(" --llocal=")
    buff.write(str(args.llocal))

# No Model
if args.nomodel == "True":
    buff.write(" --nomodel")

# Extension Size
if args.extsize != 200:
    buff.write(" --extsize=")
    buff.write(str(args.extsize))

# Shift
if args.shift != 0:
    buff.write(" --shift=")
    buff.write(str(args.shift))

# Keep Dup
if args.keepdup != 1:
    buff.write(" --keep-dup=")
    buff.write(str(args.keepdup))

# Broad Peaks
if args.broad == "True":
    buff.write(" --broad")

# Broad Cutoff
if args.broadcutoff != 0.1:
    buff.write(" --broad-cutoff=")
    buff.write(str(args.broadcutoff))

# Scale To
if args.scaleto:
    buff.write(" --scale-to=")
    buff.write(str(args.scaleto))

# Bdg file
if args.bdg == "True":
    buff.write(" -B")

# Call Summits
if args.callsummits == "True":
    buff.write(" --call-summits")

# Buffer Size
if args.buffersize != 100000:
    buff.write(" --buffer-size=")
    buff.write(str(args.buffersize))

command_str = buff.getvalue()
print(command_str)

# # now call it passing along the same environment we got
# sys.stdout.write(command_str)
# sys.exit(0)
subprocess = subprocess.Popen(command_str, shell = True, stdout=PIPE)
subprocess_return = subprocess.stdout.read()
print(subprocess_return)
# childProcess = subprocess.Popen(command_str, shell=True, env=os.environ, stdout=PIPE, stderr=PIPE)
# stdout, stderr = childProcess.communicate()
# retval = childProcess.returncode
# if (retval != 0):
#     print( stdout ) 
#     print  >> sys.stderr, stderr

# else:
#     print(stdout)
#     print(stderr)
# sys.exit(retval)